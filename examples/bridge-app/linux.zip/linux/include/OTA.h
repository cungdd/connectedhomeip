
void InitOTARequestor(void);
int RunOTARequestor(void);